import os
from json import JSONEncoder
import re
import requests
# pip install httpagentparser
import httpagentparser  # for getting the user agent as json
import nltk
from flask import Flask, render_template, session
from flask import request
import gensim
from gensim.models import Word2Vec
import multiprocessing

from myapp.analytics.analytics_data import AnalyticsData, ClickedDoc, SearchedQuery, IP_directions, Agents
from myapp.search.load_corpus import load_corpus
from myapp.search.objects import Document, StatsDocument, ResultItem
from myapp.search.search_engine import search
from myapp.search.load_tfidf import load_tfidf
from myapp.search.load_tfidf import create_index




# *** for using method to_json in objects ***
def _default(self, obj):
    return getattr(obj.__class__, "to_json", _default.default)(obj)

def get_ip_info(ip_address):
    response = requests.get(f"http://ip-api.com/json/{ip_address}")
    data = response.json()
    return data

_default.default = JSONEncoder().default
JSONEncoder.default = _default

# end lines ***for using method to_json in objects ***

# instantiate the Flask application
app = Flask(__name__)

# random 'secret_key' is used for persisting data in secure cookie
app.secret_key = 'afgsreg86sr897b6st8b76va8er76fcs6g8d7'
# open browser dev tool to see the cookies
app.session_cookie_name = 'IRWA_SEARCH_ENGINE'

# instantiate our search engine
#search_engine = SearchEngine()

# instantiate our in memory persistence
analytics_data = AnalyticsData()
analytics_data.load_data()

# print("current dir", os.getcwd() + "\n")
# print("__file__", __file__ + "\n")
full_path = os.path.realpath(__file__)
path, filename = os.path.split(full_path)
# print(path + ' --> ' + filename + "\n")
# load documents corpus into memory.
file_path = path + "/Rus_Ukr_war_data.json"
tfidf_path = path + '/tf_idf_data.json'

# file_path = "../../tweets-data-who.json"
corpus, formatted_tweets, tweets_relevant, Diccionario_Num2ID, resultado_diccionarios = load_corpus(file_path)
print("loaded corpus. first elem:", list(corpus.values())[0])
tf,df,idf,title_index = load_tfidf(tfidf_path, tweets_relevant)
indexx = create_index(tweets_relevant)
print("loaded tfidf")

sentences = [text[1] for text in tweets_relevant]
words = []
for tw in sentences:
    for w in tw:
      words.append(w)

#Entrenamos el modelo
training_data = sentences
model = Word2Vec(training_data, vector_size=200, window=5, min_count=5, workers=multiprocessing.cpu_count())


# Home URL "/"
@app.route('/')
def index():
    print("starting home url /...")

    # flask server creates a session by persisting a cookie in the user's browser.
    # the 'session' object keeps data between multiple requests
    session['some_var'] = "IRWA 2021 home"

    user_agent = request.headers.get('User-Agent')
    print("Raw user browser:", user_agent)

    user_ip = request.remote_addr
    agent = httpagentparser.detect(user_agent)

    print("Remote IP: {} - JSON user browser {}".format(user_ip, agent))
    analytics_data.save_sesion_terms(user_ip, agent)
    print(session)

    return render_template('index.html', page_title="Welcome")


@app.route('/search', methods=['POST'])
def search_form_post():
    search_query = request.form['search-query']
    search_engine = request.form.get('search-engine')
    
    session['last_search_query'] = search_query

    search_id = analytics_data.save_query_terms(search_query)
    print(search_query)

    results = search(search_query,corpus, indexx, idf,tf, title_index, search_engine, formatted_tweets, Diccionario_Num2ID, model, tweets_relevant)
    Tweets_result = []
    for Rank, id in enumerate(results):
        doc = resultado_diccionarios[id]
        Tweets_result.append(Document(id,
                                        f"{corpus[doc][0][:20]}...",
                                        corpus[doc][0],
                                        corpus[doc][1],
                                        corpus[doc][-3],
                                        corpus[doc][-2],
                                        corpus[doc][-1],
                                        corpus[doc][2:-3]))

    Full_results = ()
    found_count = len(results)
    session['last_found_count'] = found_count

    print(session)

    return render_template('results.html', results_list=Tweets_result, page_title="Results", found_counter=found_count)


@app.route('/doc_details', methods=['GET'])
def doc_details():
    # getting request parameters:
    # user = request.args.get('user')

    print("doc details session: ")
    print(session)

    res = session["some_var"]

    print("recovered var from session:", res)

    # get the query string parameters from request
    print("request.args",request.args)
    clicked_doc_id = request.args["id"]
    
    id = request.args["id"]  # transform to Integer
    doc = resultado_diccionarios[id]
    Tweet = Document(id,
                corpus[doc][0],
                corpus[doc][0],
                corpus[doc][1],
                corpus[doc][-3],
                corpus[doc][-2],
                corpus[doc][-1],
                corpus[doc][2:-3])
    print("click in id={}".format(clicked_doc_id))

    # store data in statistics table 1
    if clicked_doc_id in analytics_data.fact_clicks.keys():
        analytics_data.fact_clicks[clicked_doc_id] += 1
    else:
        analytics_data.fact_clicks[clicked_doc_id] = 1
    analytics_data.save_click_terms()
    print("fact_clicks count for id={} is {}".format(clicked_doc_id, analytics_data.fact_clicks[clicked_doc_id]))

    return render_template('doc_details.html', Tweet_result = Tweet)


@app.route('/stats', methods=['GET'])
def stats():
    """
    Show simple statistics example. ### Replace with dashboard ###
    :return:
    """

    docs = []
    # ### Start replace with your code ###
    
    for doc_id in analytics_data.fact_clicks:
        doc = resultado_diccionarios[doc_id]
        row = Document(doc_id,
                corpus[doc][0],
                corpus[doc][0],
                corpus[doc][1],
                corpus[doc][-3],
                corpus[doc][-2],
                corpus[doc][-1],
                corpus[doc][2:-3])
        
        count = analytics_data.fact_clicks[doc_id]
        doc = StatsDocument(row.id, row.title, row.description, row.doc_date, row.url, count)
        docs.append(doc)

    # simulate sort by ranking
    docs.sort(key=lambda doc: doc.count, reverse=True)
    
    return render_template('stats.html', clicks_data=docs)
    # ### End replace with your code ###


@app.route('/dashboard', methods=['GET'])
def dashboard():
    visited_docs = []
    writen_queries = []
    ip_info = []
    Agent_info = []
    print(analytics_data.fact_clicks.keys())
    print(analytics_data.fact_query.keys())
    for doc_id in analytics_data.fact_clicks.keys():
        docu = resultado_diccionarios[doc_id]
        d = Document(doc_id,
                corpus[docu][0],
                corpus[docu][0],
                corpus[docu][1],
                corpus[docu][-3],
                corpus[docu][-2],
                corpus[docu][-1],
                corpus[docu][2:-3])
        doc = ClickedDoc(int(docu), d.description, analytics_data.fact_clicks[doc_id])
        visited_docs.append(doc)
    

    # simulate sort by ranking
    visited_docs.sort(key=lambda doc: doc.counter, reverse=True)
    for doc in visited_docs: print(doc)
    visited_docs =  [doc.to_json() for doc in visited_docs]

    
    for query in analytics_data.fact_query.keys():
        texto_sin_puntuacion = re.sub(r'[^\w\s]', '', query)
        palabras = texto_sin_puntuacion.split()
        Num_words = len(palabras)
        query = SearchedQuery(query, Num_words, analytics_data.fact_query[query])
        writen_queries.append(query)

    writen_queries.sort(key=lambda query: query.counter, reverse=True)
    for query in writen_queries: print(query)
    writen_queries =  [query.to_json() for query in writen_queries]

    #ip
    for ip in analytics_data.fact_count.keys():
        ip_data = IP_directions(ip, analytics_data.fact_count[ip])
        ip_info.append(ip_data)
    ip_info.sort(key=lambda ip_data: ip_data.counter, reverse=True)
    for ip in ip_info: print(ip)
    ip_info =  [ip.to_json() for ip in ip_info]

    #analytics data
    for data in analytics_data.fact_agent.keys():
        Agent_data = Agents(analytics_data.fact_agent[data][1], analytics_data.fact_agent[data][2], analytics_data.fact_agent[data][3], analytics_data.fact_agent[data][0])
        
        Agent_info.append(Agent_data)
        print("Info del agente", Agent_data)
    Agent_info.sort(key=lambda Agent_data: Agent_data.counter, reverse=True)
    print("Info del agente2", Agent_info)
    for data in Agent_info: print(ip)
    Agent_info =  [Agent.to_json() for Agent in Agent_info]

    print("Info del agente3", Agent_info)
    #Aqui es tindria que pasar writen_queries, ip_info y Agent_info
    return render_template('dashboard.html', visited_docs=visited_docs, writen_queries = writen_queries, ip_info = ip_info, Agent_info = Agent_info)


@app.route('/sentiment')
def sentiment_form():
    return render_template('sentiment.html')


@app.route('/sentiment', methods=['POST'])
def sentiment_form_post():
    text = request.form['text']
    nltk.download('vader_lexicon')
    from nltk.sentiment.vader import SentimentIntensityAnalyzer
    sid = SentimentIntensityAnalyzer()
    score = ((sid.polarity_scores(str(text)))['compound'])
    return render_template('sentiment.html', score=score)


if __name__ == "__main__":
    app.run(port=8088, host="0.0.0.0", threaded=False, debug=True)
