import nltk
nltk.download('stopwords')

from collections import defaultdict
from array import array
import time
from nltk.stem import PorterStemmer
from nltk.corpus import stopwords
import math
import numpy as np
import collections
from numpy import linalg as la
import json
import matplotlib.pyplot as plt
import re
import pandas as pd
from sklearn.metrics.pairwise import cosine_similarity




def search_in_corpus(query, docs, index, idf, tf, title_index):
    query = build_terms(query)
    docs = set()
    i=0

    for term in query:
        try:
            # store in term_docs the ids of the docs that contain "term"
            term_docs=[posting[0] for posting in index[term]]

            if i == 0 : docs = docs.union(term_docs)
            else : docs = docs.intersection(term_docs)
            i+=1
        except:
            #term is not in index
            pass
    docs = list(docs)

    ranked_docs, doc_scores = rank_documents(query, docs, index, idf, tf, title_index)

    return ranked_docs

def search_Interactions(query, index, formatted_tweets, resultado_diccionarios):
    """
    output is the list of documents that contain all of the query terms.
    So, we will get the list of documents for each query term, and take the intersection of them.
    """
    query = build_terms(query)
    docs = set()

    i=0

    for term in query:
        try:
            # store in term_docs the ids of the docs that contain "term"
            term_docs=[posting[0] for posting in index[term]]

            if i == 0 : docs = docs.union(term_docs)
            else : docs = docs.intersection(term_docs)
            i+=1
        except:
            #term is not in index
            pass
    docs = list(docs)


    ranked_docs, doc_scores = rank_interactions(query, docs, index, formatted_tweets, resultado_diccionarios)

    return ranked_docs


def search_word2vec(query, index, model, tweets_relevant):
    """
    output is the list of documents that contain any of the query terms.
    So, we will get the list of documents for each query term, and take the union of them.
    """
    query = build_terms(query)
    docs = set()

    i=0
    for term in query:
        try:
            # store in term_docs the ids of the docs that contain "term"
            term_docs=[posting[0] for posting in index[term]]

            if i == 0 : docs = docs.union(term_docs)
            else : docs = docs.intersection(term_docs)
            i+=1
        except:
            #term is not in index
            pass

    docs = list(docs)

    ranked_docs, doc_scores = rank_docs_word2vec(query, index, docs, model, tweets_relevant)

    return ranked_docs

#elimina emojis del texto
def remove_emojis(text):
    emoji_pattern = re.compile("["
                           u"\U0001F600-\U0001F64F"  # Emojis in Emoticons
                           u"\U0001F300-\U0001F5FF"  # Emojis in Miscellaneous Symbols and Pictographs
                           u"\U0001F680-\U0001F6FF"  # Emojis in Transport and Map Symbols
                           u"\U0001F700-\U0001F77F"  # Emojis in Alphabetic Presentation Forms
                           u"\U0001F780-\U0001F7FF"  # Emojis in Geometric Shapes Extended
                           u"\U0001F800-\U0001F8FF"  # Emojis in Supplemental Arrows-C
                           u"\U0001F900-\U0001F9FF"  # Emojis in Supplemental Symbols and Pictographs
                           u"\U0001FA00-\U0001FA6F"  # Emojis in Chess Symbols
                           u"\U0001FA70-\U0001FAFF"  # Emojis in Symbols and Pictographs Extended-A
                           u"\U0001F004-\U0001F0CF"  # Mahjong Tiles
                           u"\U0001F170-\U0001F251"  # Emojis in Enclosed Alphanumeric Supplement
                           "]+", flags=re.UNICODE)

    # Remove emojis from the text
    return emoji_pattern.sub(r'', text)

def clean_tweet(tweet):
    # Remove special characters, punctuation, and numbers
    cleaned_tweet = re.sub(r'[^\w\s#]', '', tweet)

    return cleaned_tweet

def build_terms(line):
    

    stemmer = PorterStemmer()
    stop_words = set(stopwords.words("english"))

    line=  line.lower() ## Transform in lowercase
    line=  remove_emojis(line)
    line= clean_tweet(line)
    line=  line.split() ## Tokenize the text to get a list of terms
    line= [x for x in line if x not in stop_words]  ##eliminate the stopwords (HINT: use List Comprehension)
    line= [stemmer.stem(x) for x in line] ## perform stemming (HINT: use List Comprehension)

    return line






def rank_documents(terms, docs, index, idf, tf, title_index):
    
    doc_vectors = defaultdict(lambda: [0] * len(terms)) # I call doc_vectors[k] for a nonexistent key k, the key-value pair (k,[0]len(terms)) will be automatically added to the dictionary
    query_vector = [0] * len(terms)

    # compute the norm for the query tf
    query_terms_count = collections.Counter(terms)  
    query_norm = la.norm(list(query_terms_count.values()))

    for termIndex, term in enumerate(terms):  #termIndex is the index of the term in the query
        if term not in index:
            continue

        ## Compute tfidf(normalize TF as done with documents)
        query_vector[termIndex]=(query_terms_count[term]/query_norm) * idf[term]
        #Generate doc_vectors for matching docs
        for doc_index, (doc, postings) in enumerate(index[term]):
            
            if doc in docs:
                doc_vectors[doc][termIndex] = tf[term][doc_index] * idf[term]  # TODO: check if multiply for idf

    

    doc_scores=[[np.dot(curDocVec, query_vector), doc] for doc, curDocVec in doc_vectors.items()]
    score = doc_scores
    doc_scores.sort(reverse=True)
    result_docs = [x[1] for x in doc_scores]
    #print document titles instead if document id's
    #result_docs=[ title_index[x] for x in result_docs ]
    if len(result_docs) == 0:
        print("No results found, try again")
        query = input()
        docs = search_tf_idf(query, index, idf, tf, title_index)
    #print ('\n'.join(result_docs), '\n')
    return result_docs, score


def rank_interactions(terms, docs, index, formatted_tweets, resultado_diccionarios):
    doc_scores = []
    for tweet in formatted_tweets:
      if resultado_diccionarios[tweet[0]] in docs:

        doc_scores.append([(tweet[-3]+2*tweet[-2]),resultado_diccionarios[tweet[0]]])

    score = doc_scores
    doc_scores.sort(reverse=True)
    result_docs = [x[1] for x in doc_scores]
    
    return result_docs, score

def rank_docs_word2vec(query, index, sentences, model, tweets_relevant):
  # Pasa avector las frases haciendo la mean de las palabras de la frase
  sentence_embeddings = []
  IDembedings = []

  for sentence in sentences:
    for tweet in tweets_relevant:

      if sentence == tweet[0]:
        valid_words = [word for word in tweet[1] if word in model.wv]  # Filter valid words

        if valid_words:
            sentence_vector = np.mean([model.wv[word] for word in valid_words], axis=0)  # Calculate the mean vector

            IDembedings.append([tweet[0],sentence_vector])
            sentence_embeddings.append(sentence_vector)

  sentence_embeddings = np.array(sentence_embeddings)

  #Calculamos el valor de la query
  query_vector = [word for word in query if word in model.wv]  # Filter valid words
  if query_vector:
      query_vector = np.mean([model.wv[word] for word in query_vector], axis=0)  # Calculate the mean vector


  # Calculate the cosine similarity between the query vector and each doc vector
  doc_scores = [(doc, cosine_similarity([query_vector], [doc_vec])[0][0]) for doc, doc_vec in IDembedings]

  score = doc_scores
  doc_scores.sort(key=lambda x: x[1], reverse=True)

  result_docs = [x[0] for x in doc_scores]

  if len(result_docs) == 0:
      print("No results found, try an other query")
  return result_docs, score

def search_tf_idf(query, index, idf, tf, title_index):
   
    query = build_terms(query)
    docs = set()

    i=0

    for term in query:
        try:
            # store in term_docs the ids of the docs that contain "term"
            term_docs=[posting[0] for posting in index[term]]

            if i == 0 : docs = docs.union(term_docs)
            else : docs = docs.intersection(term_docs)
            i+=1
        except:
            #term is not in index
            pass
    docs = list(docs)

    ranked_docs, doc_scores = rank_documents(query, docs, index, idf, tf, title_index)

    return ranked_docs, doc_scores