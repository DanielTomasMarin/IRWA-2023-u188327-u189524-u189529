import random

from myapp.search.objects import ResultItem, Document
from myapp.search.algorithms import search_in_corpus
from myapp.search.algorithms import search_Interactions
from myapp.search.algorithms import search_word2vec



def build_demo_results(corpus: dict, search_id):
    """
    Helper method, just to demo the app
    :return: a list of demo docs sorted by ranking
    """
    res = []
    size = len(corpus)
    ll = list(corpus.values())
    for index in range(random.randint(0, 40)):
        item: Document = ll[random.randint(0, size)]
        res.append(ResultItem(item.id, item.title, item.description, item.doc_date,
                              "doc_details?id={}&search_id={}&param2=2".format(item.id, search_id), random.random()))

    # for index, item in enumerate(corpus['Id']):
    #     # DF columns: 'Id' 'Tweet' 'Username' 'Date' 'Hashtags' 'Likes' 'Retweets' 'Url' 'Language'
    #     res.append(DocumentInfo(item.Id, item.Tweet, item.Tweet, item.Date,
    #                             "doc_details?id={}&search_id={}&param2=2".format(item.Id, search_id), random.random()))

    # simulate sort by ranking
    res.sort(key=lambda doc: doc.ranking, reverse=True)
    return res


def search(search_query, corpus,indexx,idf,tf, title_index, search_engine, formatted_tweets, resultado_diccionarios, model, tweets_relevant):
    print("Search query:", search_query)

    results = []
    ##### your code here #####
    #results = build_demo_results(corpus, search_id)  # replace with call to search algorithm
    if search_engine == 'social_relevance':
        results = search_Interactions(search_query, indexx, formatted_tweets, resultado_diccionarios)
    elif search_engine == 'word2vec':
        results = search_word2vec(search_query, indexx, model, tweets_relevant)
    else:
        results = search_in_corpus(search_query, corpus,indexx, idf, tf, title_index)
    ##### your code here #####

    return results
