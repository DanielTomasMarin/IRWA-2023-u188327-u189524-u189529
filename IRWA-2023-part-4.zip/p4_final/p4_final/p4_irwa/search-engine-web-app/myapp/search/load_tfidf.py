import pandas as pd
import json
import os
from collections import defaultdict
from array import array
import math
import numpy as np


from myapp.core.utils import load_json_file
from myapp.search.objects import Document
from myapp.search.algorithms import build_terms


def load_tfidf(path, tweets_relevant):
    # Comprueba si el archivo existe
    if os.path.exists('tf_idf_data.json'):
        # Si existe, abre el archivo y carga los datos en las variables
        with open('tf_idf_data.json', 'r') as f:
            data = json.load(f)
            tf = data['tf']
            df = data['df']
            idf = data['idf']
            title_index = data['title_index']
        
    else:
        # Si no existe, ejecuta tu función para asignar valores a las variables
        tf, df, idf, title_index = TF_IDF_INDEX(tweets_relevant,len(tweets_relevant))

    
        # Guarda las variables en un archivo JSON
        data = {'tf': tf, 'df': df, 'idf': idf, 'title_index': title_index}
        with open('tf_idf_data.json', 'w') as f:
            json.dump(data, f)

    return tf,df,idf,title_index

def TF_IDF_INDEX(lines,num_documents):
    
    index = defaultdict(list)
    tf = defaultdict(list)
    df = defaultdict(int)  # document frequencies of terms in the corpus
    title_index = defaultdict(str)
    idf = defaultdict(float)
    for line_arr in lines:  # Remember, lines contain all documents: article-id | article-title | article-body

        page_id = line_arr[0]
        terms = line_arr[1] # page_title + page_text
        relevant_words = line_arr[1]


        current_page_index = {}

        for position, term in enumerate(terms): # terms contains page_title + page_text. Loop over all terms
            try:

                current_page_index[term][page_id].append(position)
            except:
                # Add the new term as dict key and initialize the array of positions and add the position
                current_page_index[term]=[page_id, array('I',[position])] #'I' indicates unsigned int (int in Python)

        #merge the current page index with the main index
        for term_page, posting_page in current_page_index.items():
            index[term_page].append(posting_page)

        norm = 0
        for term, posting in current_page_index.items():
            
            norm += len(posting[1]) ** 2
        norm = math.sqrt(norm)

        # calculate the tf(dividing the term frequency by the above computed norm) and df weights
        for term, posting in current_page_index.items():
            # append the tf for current term (tf = term frequency in current doc/norm)
            tf[term].append(np.round(len(posting[1])/norm,4)) ## SEE formula (1) above
            #increment the document frequency of current term (number of documents containing the current term)
            df[term] += 1 # increment DF for current term

        #merge the current page index with the main index
        for term_page, posting_page in current_page_index.items():
            index[term_page].append(posting_page)

        # Compute IDF following the formula (3) above. HINT: use np.log
        for term in df:
            idf[term] = np.round(np.log(float(num_documents/df[term]+1)), 4)

    

    return tf, df, idf, title_index

def create_index(lines):
    """
    Implement the inverted index

    Argument:
    lines -- collection of Wikipedia articles

    Returns:
    index - the inverted index (implemented through a Python dictionary) containing terms as keys and the corresponding
    list of documents where these keys appears in (and the positions) as values.
    """
    index = defaultdict(list)

    for line_arr in lines:  # Remember, lines contain all documents: article-id | article-title | article-body

        page_id = line_arr[0]
        terms = line_arr[1] # page_title + page_text
        relevant_words = line_arr[1]

        ## ===============================================================
        ## create the index for the current page and store it in current_page_index (current_page_index)
        ## current_page_index ==> { ‘term1’: [current_doc, [list of positions]], ...,‘term_n’: [current_doc, [list of positions]]}

        ## Example: if the curr_doc has id 1 and his text is
        ##"web retrieval information retrieval":

        ## current_page_index ==> { ‘web’: [1, [0]], ‘retrieval’: [1, [1,4]], ‘information’: [1, [2]]}

        ## the term ‘web’ appears in document 1 in positions 0,
        ## the term ‘retrieval’ appears in document 1 in positions 1 and 4
        ## ===============================================================

        current_page_index = {}

        for position, term in enumerate(terms): # terms contains page_title + page_text. Loop over all terms
            try:
                # if the term is already in the index for the current page (current_page_index)
                # append the position to the corresponding list


                current_page_index[term][page_id].append(position)
            except:
                # Add the new term as dict key and initialize the array of positions and add the position
                current_page_index[term]=[page_id, array('I',[position])] #'I' indicates unsigned int (int in Python)

        #merge the current page index with the main index
        for term_page, posting_page in current_page_index.items():
            index[term_page].append(posting_page)


    return index