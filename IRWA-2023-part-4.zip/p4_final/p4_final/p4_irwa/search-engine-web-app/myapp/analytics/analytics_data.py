import json
import random
import os
import re

class AnalyticsData:
    """
    An in memory persistence object.
    Declare more variables to hold analytics tables.
    """
    # statistics table 1
    # fact_clicks is a dictionary with the click counters: key = doc id | value = click counter
    fact_clicks = dict([])

    # statistics table 2
    fact_query = dict([])

    # statistics table 3
    fact_count = dict([])

    # statistics table 4
    fact_agent = dict([])

    def load_data(self):
        if os.path.exists('data.json'):
            with open('data.json', 'r') as f:
                data = json.load(f)
                self.fact_clicks = data.get('fact_clicks', {})
                self.fact_query = data.get('fact_query', {})
                self.fact_count = data.get('fact_count', {})
                self.fact_agent = data.get('fact_agent', {})

        else:
            with open('data.json', 'w') as f:
                json.dump({'fact_clicks': self.fact_clicks, 'fact_query': self.fact_query, 'fact_count': self.fact_count, 'fact_agent': self.fact_agent}, f)

    def save_data(self):
        with open('data.json', 'w') as f:
            json.dump({'fact_clicks': self.fact_clicks, 'fact_query': self.fact_query, 'fact_count': self.fact_count, 'fact_agent': self.fact_agent}, f)

    def save_query_terms(self, terms) -> int:
        if terms in self.fact_query:
            self.fact_query[terms] = self.fact_query[terms]+1
        else:
            self.fact_query[terms] = 1
        self.save_data()
        print(f"Tu query es: {terms}")
        return id

    def save_click_terms(self):
        self.save_data()
        return 0

    def save_sesion_terms(self, ip, agent) -> int:
        if ip in self.fact_count:
            self.fact_count[ip] = self.fact_count[ip] + 1
        else:
            self.fact_count[ip] = 1
        key = str(agent)

        if key in self.fact_agent:
            self.fact_agent[key] = [self.fact_agent[key][0] + 1, agent['platform']['name'], agent['browser']['name'], agent['browser']['version']]
        else:
            self.fact_agent[key] = [1, agent['platform']['name'], agent['browser']['name'], agent['browser']['version']]

        self.save_data()
        print("Se ha iniciado la sesion")
        return ip


class ClickedDoc:
    def __init__(self, doc_id, description, counter):
        self.doc_id = doc_id
        self.description = description
        self.counter = counter


    def to_json(self):
        return self.__dict__

    def __str__(self):
        """
        Print the object content as a JSON string
        """
        return json.dumps(self)
    
class SearchedQuery:
    def __init__(self, query, num_words, counter):
        self.query = query
        self.NumWords = num_words
        self.counter = counter


    def to_json(self):
        return self.__dict__


    def __str__(self):
        """
        Print the object content as a JSON string
        """
        return json.dumps(self)
    

class IP_directions:
    def __init__(self, ip, counter):
        self.ip = ip
        self.counter = counter


    def to_json(self):
        return self.__dict__


    def __str__(self):
        """
        Print the object content as a JSON string
        """
        return json.dumps(self)
    
class Agents:
    def __init__(self, operative_sistem, browser_type, browser_version, counter):
        self.operative_sistem = operative_sistem
        self.browser_type = browser_type
        self.browser_version = browser_version
        self.counter = counter


    def to_json(self):
        return self.__dict__


    def __str__(self):
        """
        Print the object content as a JSON string
        """
        return json.dumps(self)